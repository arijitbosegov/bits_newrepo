# Save It
A NextJs Website to Learn about FrontEnd Development!

Give it a look at [hnp-save-it.vercel.app](https://hnp-save-it.vercel.app/)

## Getting Started
First, Install the dependencies
```bash 
pnpm i

```

then, run the development server:

```bash
pnpm dev
```